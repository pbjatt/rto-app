@include('backend.common.header')
@include('backend.template.sidebar')
@include('backend.inc.'.$page)
@include('backend.common.footer')
