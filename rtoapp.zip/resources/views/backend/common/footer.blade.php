    {{ HTML::script('assets/js/app.min.js') }}
    {{ HTML::script('assets/js/form.min.js') }}
    {{ HTML::script('assets/js/custom-script.js') }}
    {{ HTML::script('assets/js/pages/forms/basic-form-elements.js') }}
    {{ HTML::script('assets/js/pages/forms/advanced-form-elements.js') }}
    <!-- {{ HTML::script('assets/js/chart.min.js') }} -->
    {{ HTML::script('assets/js/admin.js') }}
    {{ HTML::script('assets/js/pages/dashboard/dashboard3.js') }}
    <!-- {{ HTML::script('assets/js/pages/todo/todo.js') }} -->
</body>
</html>