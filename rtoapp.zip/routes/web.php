<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::group(['middleware' => 'guest', 'prefix' => 'admin', 'as' => 'admin.'], function () {
// 	Route::get('/login', 'LoginController@index')->name('login');
// 	Route::post('/checklogin', 'LoginController@checklogin')->name('checklogin');
// });

// Route::group(['middleware' => 'auth', 'prefix' => 'admin', 'as' => 'admin.'], function () {

//     Route::get('/home', 'DashboardController@index')->name('home');	

// 	Route::get('/logout', 'LoginController@logout')->name('logout');

//     Route::get('/setting', 'SettingController@edit')->name('setting.edit');
//     Route::post('/setting', 'SettingController@update')->name('setting.update');

//     Route::get('/change-password', 'LoginController@change_password')->name('user.edit');
//     Route::post('/change-password', 'LoginController@save_password')->name('user.update');

// 	Route::resources([
//         'age' => 'AgeController',
//         'cubiccapacity' => 'CubicCapacityController',
//         'idv' => 'IdvrateController',
//         'price' => 'PriceController',
//     ]);

// });


Route::group(['middleware' => 'guest', 'prefix' => 'admin'], function () {
    Route::any('/login', 'LoginController@index')->name('login');
    Route::post('main/checklogin', 'LoginController@checklogin')->name('checklogin');
});

Route::group(['middleware' => 'auth', 'prefix' => 'admin'], function () {
    Route::get('logout', 'LoginController@logout')->name('logout');
    Route::get('/', 'DashboardController@index')->name('admin-home');
});

Route::group(['middleware' => 'auth', 'as' => 'admin.', 'prefix' => 'admin'], function () {

    Route::resources([
        'age' => 'AgeController',
        'cubiccapacity' => 'CubicCapacityController',
        'idv' => 'IdvrateController',
        'price' => 'PriceController'
    ]);

    Route::resources([
        'slider' => 'SliderController',
        'tool' => 'ToolController',
        'type' => 'TypeController',
    ]);

    Route::group(['prefix' => 'user'], function () {
        Route::get('/', 'UserController@list');
    });


    Route::group(['prefix' => 'profile'], function () {
        Route::get('/', 'LoginController@profile')->name('profile');
        Route::post('/', 'LoginController@edit_profile')->name('profile');
    });

    Route::group(['prefix' => 'setting'], function () {
        Route::get('/', 'SettingController@edit')->name('setting');
        Route::post('/', 'SettingController@update')->name('setting');
    });
});
