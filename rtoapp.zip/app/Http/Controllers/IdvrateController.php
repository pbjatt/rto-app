<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Age;
use App\Models\CubicCapacity;
use App\Models\Idvrate;

class IdvrateController extends Controller
{
    public function index()
    {
        $lists = Idvrate::with('cubiccapacity','ageyears')->get();

        // set page and title -------------
        $page  = 'idv.list';
        $title = 'idv list';
        $data  = compact('page', 'title', 'lists');

        return view('backend.layout.master', $data);
    }

    public function create()
    {
        $cc = CubicCapacity::get();
        $ccArr  = ['' => 'Select Cubic Capacity'];
        if (!$cc->isEmpty()) {
            foreach ($cc as $pcat) {
                $ccArr[$pcat->id] = $pcat->cc_range;
            }
        }

        $age = Age::get();
        $ageArr  = ['' => 'Select Range'];
        if (!$age->isEmpty()) {
            foreach ($age as $pcat) {
                $ageArr[$pcat->id] = $pcat->age;
            }
        }

        $zoneArr  = [
            ''  => 'Select Zone',
            'A' => 'A',
            'B' => 'B'
        ];

        // set page and title -------------
        $page  = 'idv.add';
        $title = 'idv Add';
        $data  = compact('page', 'title', 'ccArr', 'ageArr', 'zoneArr');

        return view('backend.layout.master', $data);
    }

    public function store(Request $request)
    {
        $rules = [
            'record'        => 'required|array',
            'record.idv'  => 'required',
        ];
        
        $messages = [
            'record.idv'  => 'Please Enter Idv.',
        ];
        
        $request->validate( $rules, $messages );
        
        $record           = new Idvrate;
        $input            = $request->record;

        $record->fill($input);
        if ($record->save()) {  
            return redirect( route('admin.idv.index') )->with('success', 'Success! New record has been added.');
        } else {
            return redirect( route('admin.idv.index') )->with('danger', 'Error! Something going wrong.');
        }
    }

    public function show(Idvrate $Idvrate)
    {
        //
    }

    public function edit(Request $request, Idvrate $idv)
    {
        $editData =  ['record'=>$idv->toArray()];
        $request->replace($editData);
        $request->flash();

        $cc = CubicCapacity::get();
        $ccArr  = ['' => 'Select Cubic Capacity'];
        if (!$cc->isEmpty()) {
            foreach ($cc as $pcat) {
                $ccArr[$pcat->id] = $pcat->cc_range;
            }
        }

        $age = Age::get();
        $ageArr  = ['' => 'Select Range'];
        if (!$age->isEmpty()) {
            foreach ($age as $pcat) {
                $ageArr[$pcat->id] = $pcat->age;
            }
        }

        $zoneArr  = [
            ''  => 'Select Zone',
            'A' => 'A',
            'B' => 'B'
        ];

        // set page and title -------------
        $page  = 'idv.edit';
        $title = 'idv Edit';
        $data  = compact('page', 'title', 'ccArr', 'idv', 'ageArr', 'zoneArr');

        return view('backend.layout.master', $data);
    }

    public function update(Request $request, Idvrate $idv)
    {
        $record     = $idv;
        $input      = $request->record; 
        
        $record->fill($input);
        if ($record->save()) {
            return redirect( route('admin.idv.index') )->with('success', 'Success! Record has been edided');
        }
    }

    public function destroy(Idvrate $idv)
    {
        $idv->delete();
        return redirect()->back()->with('success', 'Success! Record has been deleted');
    }
}
