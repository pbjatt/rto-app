<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CubicCapacity;
use App\Models\Price;

class PriceController extends Controller
{
    public function index()
    {
        $lists = Price::with('cubiccapacity')->get();

        // set page and title -------------
        $page  = 'price.list';
        $title = 'Price list';
        $data  = compact('page', 'title', 'lists');

        return view('backend.layout.master', $data);
    }

    public function create()
    {
        $cc = CubicCapacity::get();
        $ccArr  = ['' => 'Select Cubic Capacity'];
        if (!$cc->isEmpty()) {
            foreach ($cc as $pcat) {
                $ccArr[$pcat->id] = $pcat->cc_range;
            }
        }
        
        $typeArr  = [
            ''  => 'Select Type',
            'New' => 'New',
            'Renewal' => 'Renewal'
        ];

        $page  = 'price.add';
        $title = 'Add price';
        $data  = compact('page', 'title', 'ccArr', 'typeArr');

        return view('backend.layout.master', $data);
    }

    public function store(Request $request)
    {
        $rules = [
            'record'        => 'required|array',
            'record.price'  => 'required',
        ];
        
        $messages = [
            'record.price'  => 'Please Enter price.',
        ];
        
        $request->validate( $rules, $messages );
        
        $record           = new Price;
        $input            = $request->record;

        $record->fill($input);
        if ($record->save()) {  
            return redirect( route('admin.price.index') )->with('success', 'Success! New record has been added.');
        } else {
            return redirect( route('admin.price.index') )->with('danger', 'Error! Something going wrong.');
        }
    }

    public function edit(Request $request, Price $price)
    {
        $editData =  ['record'=>$price->toArray()];
        $request->replace($editData);
        $request->flash();

        $cc = CubicCapacity::get();
        $ccArr  = ['' => 'Select Cubic Capacity'];
        if (!$cc->isEmpty()) {
            foreach ($cc as $pcat) {
                $ccArr[$pcat->id] = $pcat->cc_range;
            }
        }

        $typeArr  = [
            ''  => 'Select Type',
            'New' => 'New',
            'Renewal' => 'Renewal'
        ];
        
        // set page and title ------------------
        $page = 'price.edit';
        $title = 'Edit Price';
        $data = compact('page', 'title', 'price', 'ccArr', 'typeArr');

        return view('backend.layout.master', $data);
    }

    public function update(Request $request, Price $price)
    {
        $record     = $price;
        $input      = $request->record; 
        
        $record->fill($input);
        if ($record->save()) {
            return redirect( route('admin.price.index') )->with('success', 'Success! Record has been edided');
        }
    }

    public function destroy(Price $price)
    {
        $price->delete();
        return redirect()->back()->with('success', 'Success! Record has been deleted');
    }
}
