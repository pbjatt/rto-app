<?php if($message = Session::get('error')): ?>
   <div class="alert alert-danger alert-block">
     <button type="button" class="close" data-dismiss="alert">x</button>
     <?php echo e($message); ?>

   </div>
<?php endif; ?>

<?php if(count($errors->all())): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-6">
        <?php echo e(Form::text('title', '', ['class' => 'squareInput', 'placeholder'=>'Enter site name','required'=>'required'])); ?>

        <?php echo e(Form::label('title', 'Enter site name'), ['class' => 'active']); ?>

    </div>
    <div class="col-lg-6">
        <?php echo e(Form::text('tagline', '', ['class' => 'squareInput', 'placeholder'=>'Enter tagline','required'=>'required'])); ?>

        <?php echo e(Form::label('tagline', 'Enter tagline'), ['class' => 'active']); ?>

    </div>
    <div class="col-lg-6">
        <?php echo e(Form::text('mobile', '', ['class' => 'squareInput', 'placeholder'=>'Enter mobile number','required'=>'required'])); ?>

        <?php echo e(Form::label('mobile', 'Enter mobile number'), ['class' => 'active']); ?>

    </div>
    <div class="col-lg-6">
        <?php echo e(Form::text('email', '', ['class' => 'squareInput', 'placeholder'=>'Enter email','required'=>'required'])); ?>

        <?php echo e(Form::label('email', 'Enter email'), ['class' => 'active']); ?>

    </div>
    <div class="col-lg-6">
        <?php echo e(Form::file('logo',['class'=>'form-control squareInput'])); ?>

        <?php echo e(Form::label('logo', 'Choose logo'), ['class' => 'active']); ?>

    </div>
    <div class="col-lg-6">
        <?php echo e(Form::file('favicon',['class'=>'form-control squareInput'])); ?>

        <?php echo e(Form::label('favicon', 'Choose favicon'), ['class' => 'active']); ?>

    </div>
</div>
<?php /**PATH H:\xampp\htdocs\rtoapp\resources\views/backend/inc/setting/_form.blade.php ENDPATH**/ ?>