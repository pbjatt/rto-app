    <?php echo e(HTML::script('assets/js/app.min.js')); ?>

    <?php echo e(HTML::script('assets/js/form.min.js')); ?>

    <?php echo e(HTML::script('assets/js/custom-script.js')); ?>

    <?php echo e(HTML::script('assets/js/pages/forms/basic-form-elements.js')); ?>

    <?php echo e(HTML::script('assets/js/pages/forms/advanced-form-elements.js')); ?>

    <!-- <?php echo e(HTML::script('assets/js/chart.min.js')); ?> -->
    <?php echo e(HTML::script('assets/js/admin.js')); ?>

    <?php echo e(HTML::script('assets/js/pages/dashboard/dashboard3.js')); ?>

    <!-- <?php echo e(HTML::script('assets/js/pages/todo/todo.js')); ?> -->
</body>
</html><?php /**PATH H:\xampp\htdocs\rtoapp\resources\views/backend/common/footer.blade.php ENDPATH**/ ?>