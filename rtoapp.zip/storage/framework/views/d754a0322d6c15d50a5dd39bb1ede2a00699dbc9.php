<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block">
  <button type="button" class="close" data-dismiss="alert">x</button>
  <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if(count($errors->all())): ?>
<div class="alert alert-danger">
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>
<div class="row">
  <div class="col-lg-12">
    <?php echo e(Form::text('record[name]', '', ['class' => 'squareInput', 'placeholder'=>'Enter name','required'=>'required'])); ?>

    <?php echo e(Form::label('record[name]', 'Enter name'), ['class' => 'active']); ?>

  </div>
</div><?php /**PATH H:\xampp\htdocs\rtoapp\resources\views/backend/inc/type/_form.blade.php ENDPATH**/ ?>